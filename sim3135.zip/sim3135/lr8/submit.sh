#! /bin/bash

#$ -N kennetho.sim3135.lr8
#$ -hard -l mem_free=500M
#$ -ckpt reloc.5m.1m.1m
#$ -v EASA_SERVER=cviant0h.cv.hp.com,EASA_DIR=/home/easa/EASA4.3/webapps/easa/users/submitted/kennetho/sim3135/lr8
#$ -V
#$ -M kenneth.olsen@hp.com
#$ -P emag
#$ -w n
#$ -b no
#$ -ac app=DrySim,author=kennetho,requester=kennetho

./SGE_run.py
